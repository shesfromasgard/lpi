import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Filme {
    public ResultSet getAll() throws Exception {
        Connection con = Cinema.conect();
        Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = st.executeQuery("select * from filmes");

        return rs;
    }
}
