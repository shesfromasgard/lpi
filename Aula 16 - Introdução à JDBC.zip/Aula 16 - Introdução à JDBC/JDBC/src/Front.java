import javax.swing.*;
import javax.swing.border.Border;

import java.awt.event.*;
import java.sql.*;
import java.awt.*;

public class Front extends JFrame  {

    private ResultSet rs;
    private Filme filme = new Filme();

    GridBagLayout layout = new GridBagLayout();
    GridBagConstraints constraints = new GridBagConstraints();

    JTextField codigoText = new JTextField();
    JTextField nomeText = new JTextField();
    JTextField generoText = new JTextField();

    JButton primeiro = new JButton("Primeiro");
    JButton anterior = new JButton("Anterior");
    JButton proximo = new JButton("Próximo");
    JButton ultimo = new JButton("Último");

    Container containerCenter = new Container();
    Container containerSouth = new Container();

    public Front() {

        setTitle("Cadastro de Filmes");
        setSize(500, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        containerCenter.setLayout(layout);
        containerSouth.setLayout(new FlowLayout(FlowLayout.CENTER));

        constraints.fill = GridBagConstraints.BOTH;
        constraints.weighty = 0.5;
        constraints.insets = new Insets(2, 2, 2, 2);
        
        constraints.weightx = 0.5;
        addComponent(new JLabel("Código: "), 0, 0, 1, 1);
        constraints.weightx = 1;
        addComponent(codigoText, 1, 0, 1, 1);
        constraints.weightx = 0.5;
        addComponent(new JLabel("Nome: "), 0, 1, 1, 1);
        constraints.weightx = 1;
        addComponent(nomeText, 1, 1, 2, 1);
        constraints.weightx = 0.5;
        addComponent(new JLabel("Gênero: "), 0, 2, 1, 1);
        constraints.weightx = 1;
        addComponent(generoText, 1, 2, 2, 1);

        containerSouth.add(primeiro);
        containerSouth.add(anterior);
        containerSouth.add(proximo);
        containerSouth.add(ultimo);

        add(containerCenter, BorderLayout.CENTER);
        add(containerSouth, BorderLayout.SOUTH);

        codigoText.setEnabled(false);
        nomeText.setEditable(false);
        generoText.setEditable(false);

        codigoText.setDisabledTextColor(Color.BLACK);
        nomeText.setDisabledTextColor(Color.BLACK);
        generoText.setDisabledTextColor(Color.BLACK);

        Border border = BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.BLACK, 1), BorderFactory.createEmptyBorder(5, 5, 5, 5));
        Border linearBorder = BorderFactory.createLineBorder(Color.BLACK, 1);

        codigoText.setBackground(Color.WHITE);
        nomeText.setBackground(Color.WHITE);
        generoText.setBackground(Color.WHITE);

        primeiro.setBackground(Color.WHITE);
        anterior.setBackground(Color.WHITE);
        proximo.setBackground(Color.WHITE);
        ultimo.setBackground(Color.WHITE);

        codigoText.setBorder(linearBorder);
        nomeText.setBorder(linearBorder);
        generoText.setBorder(linearBorder);

        primeiro.setBorder(border);
        anterior.setBorder(border);
        proximo.setBorder(border);
        ultimo.setBorder(border);

        primeiro.addActionListener(new Handler());
        anterior.addActionListener(new Handler());
        proximo.addActionListener(new Handler());
        ultimo.addActionListener(new Handler());

        try {
            rs = filme.getAll();

            if(rs.isBeforeFirst()) {
                rs.next();
                showData();
            } else {
                JOptionPane.showMessageDialog(null, "Não há filmes cadastrados no banco.");
                primeiro.setEnabled(false);
                anterior.setEnabled(false);
                proximo.setEnabled(false);
                ultimo.setEnabled(false);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }

        setLocationRelativeTo(null);
        setVisible(true);

    }

    public void addComponent(Component c, int x, int y, int width, int height) {

        constraints.gridx = x;
        constraints.gridy = y;
        constraints.gridwidth = width;
        constraints.gridheight = height;

        containerCenter.add(c, constraints);

    }

    public void showData() {
        try {
            codigoText.setText(rs.getString("id"));
            nomeText.setText(rs.getString("nome"));
            generoText.setText(rs.getString("genero"));
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    public class Handler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ev) {

            try {
                if(ev.getSource() == primeiro) {
                    rs.first();
                }
                if(ev.getSource() == anterior) {
                    if(!rs.isFirst())
                        rs.previous();
                }
                if(ev.getSource() == proximo) {
                    if(!rs.isLast())
                        rs.next();
                }
                if(ev.getSource() == ultimo) {
                    rs.last();
                }
                showData();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }


        }
    }
}
